Proyek Pra UTS Web Technology 2
Keterangan:
1.	Source code proyek ini dapat diperoleh dari: https://github.com/richardvinc/wt21819_exerciseWeek7
2.	Proyek ini dikerjakan secara individual.
3.	Peserta diperbolehkan untuk melakukan googling, membaca dokumentasi, berdiskusi satu sama lain, namun tidak diperbolehkan untuk melakukan copy paste source code peserta lain (dalam bentuk apa pun).
4.	Pengumpulan proyek ini akan dilakukan melalui portal learning.kwikkiangie.ac.id
Instruksi:
1.	Edit source code yang diberikan agar hasil aplikasi dapat menjadi seperti contoh yang diberikan
2.	Tidak ada source code yang dihapus, hanya ada yang ditambahkan.

catatan: hasil proyek dapat dilihat di elearning
